__version__ = '1.0.1'
"""
Version of the NekoTPy module
more info in the telegram sub-module
"""
