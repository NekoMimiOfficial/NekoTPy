__version__ = "1.0.1"

"""
     ^ ^    NekoTPy telegram bot API wrapper         v Bliss(A)
    =UwU=   this software is distributed as is without warranty
     w w    developed by @NekoMimiOfficial 2023(c) NekoLabs LTD

     NekoTPy is a telegram bot API wrapper which is async ready
     and feature rich to write bots in a more elegant and simple
     style minimizing keystrokes

     this library takes inspiration of the discord.py syntax
     if you are used to it then you'll be at home since its
     almost a 1to1 syntax (minus that it's telegram)

     for more info and guides, please refer to the docs at:
     <DOCS_PLACEHOLDER>
"""
