print("This module does not run as a program")
